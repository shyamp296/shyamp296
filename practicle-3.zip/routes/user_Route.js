const path = require('path')


const express = require('express')

const router = express.Router()

const userModel = require('../models/user_model')
const userController = require('../controller/user_Controller')

const auth = require('../middleware/auth')



router.get('/', auth, userController.dashbord)

module.exports = router