const mongoose = require('mongoose')

const Schema  = mongoose.Schema

const userSchema  = new Schema({
    username : {
        type: String,
        required : true 
    },
    email : {
        type : String,
        required : true
    },
    Password :{
        type : String,
        required : true
    },
    role : {
        type : String,
        required : true
    },
    serviceId : { 
        type : Schema.Types.ObjectId ,
        ref: 'service',
        required : true

    }
})

module.exports = mongoose.model('User', userSchema)