const express = require('express')
const mongoose = require('mongoose')

const bodyParser = require('body-parser')
const path = require('path')
const cookieParser = require('cookie-parser')
const nodeMailer = require ('nodemailer')
const app = express()

app.set('view engine', 'ejs')

const userRoutes = require('./routes/user_Route')

const authRoutes = require('./routes/auth_routes')

const adminRoutes = require('./routes/admin_routes')

app.use(bodyParser.urlencoded({ extended: true }))

app.use(express.static(path.join(__dirname, 'public')))


app.use(cookieParser())

app.use(userRoutes)
app.use(authRoutes)
app.use(adminRoutes)


mongoose.set('strictQuery', true)
mongoose.connect('mongodb://localhost:27017/node-practicle-3').then((result) => {
    app.listen(5000)
    console.log('connection succesful');
}).catch((err) => {
    console.log(err);
});
