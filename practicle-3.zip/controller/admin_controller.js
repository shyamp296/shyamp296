const User = require('../models/user_model')
const service = require('../models/service_model')

exports.dashbord = async (req ,res, next) => {

    const users = await User.findOne({_id : id})
    service.find().then((services) =>{
    res.render('services', {
        pagetitle : 'Services',
        user: users,
        services
    })
    })
}


exports.addService = (req, res, next) => {

    User.find().then((user) => {
        console.log(user);
        res.render('add_service',{
            pagetitle : 'add service',
            user
        })
    })
}

exports.postaddService = (req , res , next) => { 
    
    const { userId, vno, pdate, ddate, location, Price } = req.body
    const Service = new service({
        vehicle_no : vno,
        Pickup_date : pdate,
        Drop_date : ddate,
        location : location,
        Price : Price,
        userId : userId
    })
    
    Service.save().then((result)=> { 
        console.log(result);
        res.redirect('/admin')
    })

}