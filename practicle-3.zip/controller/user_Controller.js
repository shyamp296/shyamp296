const path = require('path')
const User = require('../models/user_model')
const service = require('../models/service_model')


exports.dashbord = (async(req ,res) => {
    const services = await service.find({ userId: id })
    const users = await User.find({_id : id})
    res.render('home',{
        pagetitle : 'Home',
        user : users,
        services : services
    })
    
})